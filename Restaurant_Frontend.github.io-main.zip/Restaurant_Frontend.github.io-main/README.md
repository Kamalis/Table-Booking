# Frontend_Backery-or-Restaurant_GSBSP-BR27
Frontend Hackathon for Restaurant Website

This website is made for the restaurant which shows all the features provided to customers.<br>
Customer can book the seat in advance or can dine in the restaurant with family, officemates, friends.<br>

Technology Stack used <br> 
Html5<br>
Css3<br>
Bootstrap<br>
Javascript <br>

<img src="website.PNG"></img>

This website contains following features<br>
Home<br>About US<br>Team<br>Gallery<br>Reservation<br>Contact US<br>Blog<br> 
